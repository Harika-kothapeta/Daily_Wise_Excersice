package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Diagnosis;
import com.main.model.Patient;
import com.main.model.Physician;
import com.main.model.Search;

@Repository
public class PatientDaoImpl implements PatientDao {
	private static Logger log = Logger.getLogger(PatientDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void savePatient(Patient patient) {
		log.info("Inside dao savePatient()");
		sessionFactory.getCurrentSession().save(patient);
	}

	@Override
	public List<Patient> fetchPatient() {
		log.info("Inside dao fetchPatient()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Patient p");
		List<Patient> patList = query.list();
		return patList;
	}

	@Override
	public void savePhysician(Physician physician) {
		log.info("Inside dao savePhysician()");
		sessionFactory.getCurrentSession().save(physician);

	}

	@Override
	public List<Physician> fetchPhysician() {
		log.info("Inside dao fetchPhysician()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Physician ph");
		List<Physician> phyList = query.list();
		return phyList;
	}

	@Override
	public void saveDiagnosis(Diagnosis diagnosis) {
		log.info("Inside dao saveDiagnosis()");
		sessionFactory.getCurrentSession().save(diagnosis);

	}

	@Override
	public List<Diagnosis> fetchDiagnosis() {
		log.info("Inside dao fetchDiagnosis()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Diagnosis d");
		List<Diagnosis> diagList = query.list();
		return diagList;
	}

	@Override
	public void searchPhysicianByCriteria(Search search) {
		log.info("Inside Dao searchPhysicianByCriteria()");
		sessionFactory.getCurrentSession().save(search);

	}

	@Override
	public List<Physician> searchPhysician(Search search) {
		log.info("Inside Dao searchPhysician()");
		Query query = sessionFactory.getCurrentSession().createQuery(
				"from Physician p where p.state=:pstate and p.insplan=:pinsplan and p.department=:pdepartment");
		query.setParameter("pstate", search.getState());
		query.setParameter("pinsplan", search.getInsplan());
		query.setParameter("pdepartment", search.getDepartment());
		List<Physician> psList = query.list();
		return psList;
	}

}
