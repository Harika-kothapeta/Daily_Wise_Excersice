package com.main.dao;

import java.util.List;

import com.main.model.Diagnosis;
import com.main.model.Patient;
import com.main.model.Physician;
import com.main.model.Search;

public interface PatientDao {
	public void savePatient(Patient patient);

	public List<Patient> fetchPatient();

	public void savePhysician(Physician physician);

	public List<Physician> fetchPhysician();

	public void saveDiagnosis(Diagnosis diagnosis);

	public List<Diagnosis> fetchDiagnosis();

	public void searchPhysicianByCriteria(Search search);

	public List<Physician> searchPhysician(Search search);

}
