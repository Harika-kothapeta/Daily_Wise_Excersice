package com.main.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.main.model.Diagnosis;
import com.main.model.Patient;
import com.main.model.Physician;
import com.main.model.Search;
import com.main.service.PatientService;

@Controller
public class PatientController {
	private static Logger log = Logger.getLogger(PatientController.class);
	@Autowired
	private PatientService patientService;

	@RequestMapping(value = "/redirect")
	public String loadRegistrationForm() {
		return "links";
	}

	@RequestMapping(value = "/patient", method = RequestMethod.GET)
	public String loadRegistrationForm(ModelMap map) {
		log.info("Request inside loadRegistration");
		Patient patient = new Patient();
		map.addAttribute("patForm", patient);
		return "PatientSuccess";
	}

	@RequestMapping(value = "/savepat", method = RequestMethod.POST)
	public String savePatient(@Validated @ModelAttribute("patForm") Patient patient, BindingResult result,
			ModelMap map) {
		String viewPage;
		if (result.hasErrors()) {
			log.info("Validation errors occured");
			viewPage = "PatientSuccess";
		} else {
			log.info("Invoking savePatient method");
			Random r = new Random();
			int patid = r.nextInt(99999) + 10000;
			patient.setId(patid);
			patientService.savePatient(patient);
			List<Patient> patList = patientService.fetchPatient();
			map.addAttribute("patientList", patList);

			viewPage = "PatientSuccessfile";
		}
		return viewPage;
	}

	@RequestMapping(value = "/physician", method = RequestMethod.GET)
	public String loadRegistrationForm1(ModelMap map) {
		log.info("Request inside loadRegistration");
		Physician physician = new Physician();
		map.addAttribute("phyForm", physician);
		return "PhysicianSuccess";
	}

	@RequestMapping(value = "/savephy", method = RequestMethod.POST)
	public String savePhysician(@Validated @ModelAttribute("phyForm") Physician physician, BindingResult result,
			ModelMap map) {
		String viewPage1;
		if (result.hasErrors()) {
			log.info("Validation errors occured");
			viewPage1 = "PhysicianSuccess";
		} else {
			log.info("Invoking savePhysician method");
			Random r = new Random();
			int phyid = r.nextInt(899) + 1000;
			String pid = "PR" + phyid;
			physician.setId(pid);
			patientService.savePhysician(physician);
			List<Physician> phyList = patientService.fetchPhysician();
			map.addAttribute("physicianList", phyList);
			viewPage1 = "PhysicianSuccessfile";
		}
		return viewPage1;
	}

	@RequestMapping(value = "/diagnosis", method = RequestMethod.GET)
	public String loadRegistrationForm2(ModelMap map) {
		log.info("Request inside loadRegistration");
		Diagnosis diagnosis = new Diagnosis();
		map.addAttribute("diagForm", diagnosis);
		return "DiagnosisSuccess";
	}

	@RequestMapping(value = "/savediag", method = RequestMethod.POST)
	public String saveDiagnosis(@Validated @ModelAttribute("diagForm") Diagnosis diagnosis, BindingResult result,
			ModelMap map) {
		String viewPage2;
		if (result.hasErrors()) {
			log.info("Validation errors occured");
			viewPage2 = "DiagnosisSuccess";
		} else {
			log.info("Invoking saveDiagnosis method");
			Random r = new Random();
			int diagid = r.nextInt(99999) + 10000;
			diagnosis.setDiag_id(diagid);
			patientService.saveDiagnosis(diagnosis);
			List<Diagnosis> diagList = patientService.fetchDiagnosis();
			map.addAttribute("diagnosisList", diagList);

			viewPage2 = "DiagnosisSuccessfile";
		}
		return viewPage2;
	}

	@ModelAttribute("FollowUp")
	public List<String> buttonList() {
		List<String> FollowUp = new ArrayList<>();
		FollowUp.add("Yes");
		FollowUp.add("No");
		return FollowUp;
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String loadSearch(ModelMap map) {
		log.info("Request inside loadSearch method");
		Search search = new Search();
		map.addAttribute("searchForm", search);
		return "PhysicianSearch";
	}

	@RequestMapping(value = "/physearch", method = RequestMethod.POST)
	public String searchPhysicianByCriteria(@Validated @ModelAttribute("searchForm") Search search,
			BindingResult result, ModelMap map) {
		String viewPage3;
		if (result.hasErrors()) {
			log.info("Validation errors occured");
			viewPage3 = "PhysicianSearch";
		} else {
			log.info("Invoking searchPhysicianByCriteria method");
			List<Physician> psList = patientService.searchPhysician(search);
			map.addAttribute("physicianList", psList);
			viewPage3 = "PhysicianSuccessfile";
		}
		return viewPage3;
	}
}
