package com.main.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Diag1")
public class Diagnosis {
	@NotNull
	private Integer patientid;
	@Id
	private Integer diag_id;
	@NotEmpty
	private String symptoms;
	@NotEmpty
	private String diag_pro;
	@NotEmpty
	private String doctor;
	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private Date diag;
	@NotEmpty
	private String follow_up;
	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private Date dof;
	@NotNull
	private Double bill;
	@NotNull
	private Integer card_num;
	@NotEmpty
	private String mop;

	public Integer getPatientid() {
		return patientid;
	}

	public void setPatientid(Integer patientid) {
		this.patientid = patientid;
	}

	public Integer getDiag_id() {
		return diag_id;
	}

	public void setDiag_id(Integer diag_id) {
		this.diag_id = diag_id;
	}

	public String getSymptoms() {
		return symptoms;
	}

	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

	public String getDiag_pro() {
		return diag_pro;
	}

	public void setDiag_pro(String diag_pro) {
		this.diag_pro = diag_pro;
	}

	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}

	public Date getDiag() {
		return diag;
	}

	public void setDiag(Date diag) {
		this.diag = diag;
	}

	public String getFollow_up() {
		return follow_up;
	}

	public void setFollow_up(String follow_up) {
		this.follow_up = follow_up;
	}

	public Date getDof() {
		return dof;
	}

	public void setDof(Date dof) {
		this.dof = dof;
	}

	public Double getBill() {
		return bill;
	}

	public void setBill(Double bill) {
		this.bill = bill;
	}

	public Integer getCard_num() {
		return card_num;
	}

	public void setCard_num(Integer card_num) {
		this.card_num = card_num;
	}

	public String getMop() {
		return mop;
	}

	public void setMop(String mop) {
		this.mop = mop;
	}

}
