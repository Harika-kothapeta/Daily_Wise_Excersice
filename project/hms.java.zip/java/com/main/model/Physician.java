package com.main.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "physician1")
public class Physician {
	@Id
	private String id;
	@NotEmpty
	@Size(min = 6, max = 15)
	private String fname;
	@NotEmpty
	@Size(min = 6, max = 15)
	private String lname;
	@NotEmpty
	private String department;
	@NotEmpty
	private String education;
	@NotNull
	private Integer experience;
	@NotEmpty
	private String state;
	@NotEmpty
	private String insplan;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public Integer getExperience() {
		return experience;
	}

	public void setExperience(Integer experience) {
		this.experience = experience;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getInsplan() {
		return insplan;
	}

	public void setInsplan(String insplan) {
		this.insplan = insplan;
	}

}
