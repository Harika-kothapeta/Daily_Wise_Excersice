package com.main.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.PatientDao;
import com.main.model.Diagnosis;
import com.main.model.Patient;
import com.main.model.Physician;
import com.main.model.Search;

@Service
@Transactional
public class PatientServiceImpl implements PatientService {
	private static Logger log = Logger.getLogger(PatientServiceImpl.class);
	@Autowired
	private PatientDao patientDao;

	@Override
	public void savePatient(Patient patient) {
		log.info("Inside savePatient()");
		patientDao.savePatient(patient);

	}

	@Override
	public List<Patient> fetchPatient() {
		log.info("Inside fetchPatient()");
		List<Patient> patList = patientDao.fetchPatient();
		return patList;
	}

	@Override
	public void savePhysician(Physician physician) {
		log.info("Inside savePhysician()");
		patientDao.savePhysician(physician);

	}

	@Override
	public List<Physician> fetchPhysician() {
		log.info("Inside fetchPhysician()");
		List<Physician> phyList = patientDao.fetchPhysician();
		return phyList;
	}

	@Override
	public void saveDiagnosis(Diagnosis diagnosis) {
		log.info("Inside saveDiagnosis()");
		patientDao.saveDiagnosis(diagnosis);

	}

	@Override
	public List<Diagnosis> fetchDiagnosis() {
		log.info("Inside fetchDiagnosis()");
		List<Diagnosis> diagList = patientDao.fetchDiagnosis();
		return diagList;
	}

	@Override
	public void searchPhysicianByCriteria(Search search) {
		log.info("Inside searchPhysicianByCriteria()");
		patientDao.searchPhysicianByCriteria(search);

	}

	@Override
	public List<Physician> searchPhysician(Search search) {
		log.info("Inside searchPhysician()");
		List<Physician> psList = patientDao.searchPhysician(search);
		return psList;
	}

}
